<?php
	include ('src/includes/header.php');
	include ('src/includes/content.php');
	include ('src/includes/footer.php');