# KasiCare_ClientSite

KasiCare Documentation


Project Summary

The aim of the KasiCare team is to try and help make healthcare affordable for South Africans living in townships.

Submission
Your team will need to produce a 10 to 15 minute user feedback video.

Short introduction by WTC team on product idea and social/environmental problem you are looking to solve.

User Feedback Research (include 3 to 5 interviews of potential users outside of WTC) NOTE that if your user is different than your purchaser, you should be interviewing both.

Note
To find out more please email mmakwakw@student.wethinkcode.co.za

Goals

Restrictions

Dir Structure
