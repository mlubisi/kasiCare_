<section id="sign" class="wrapper post bg-img" data-bg="banner.jpg">
				<div class="inner">
					<article class="box">
						<header>
							<h2>Login To Continue</h2>
						</header>
						<div class="content">
						<form id="login" action="#" method="post">
						<div class="field">
							<label for="signIn">Username</label>
							<input name="signIn" id="signIn" type="text" placeholder="Please Enter Admin Username or Email">
						</div>
						<div class="field">
							<label for="password">Password</label>
							<input name="password" id="password" type="password" placeholder="Enter Your Password">
						</div>
						<ul class="actions">
							<li><input value="Continue" class="button alt" type="submit"></li>
						</ul>
					</form>

						</div>
						<footer>
                            <p>Or </p>
							<a href="<?php echo $_ROOT_.'?currView=signup';?>" class="button alt">Create New Account</a>
						</footer>
					</article>
				</div>
			</section>
