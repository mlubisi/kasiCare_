
	<section id="two" class="wrapper post bg-img" data-bg="banner2.jpg">
				<div class="inner">
					<article class="box">
						<header>
							<h2>Create New Account</h2>
						</header>
						<div class="content">
						<form id="register" action="#" method="post">
						<div class="field">
							<label for="practiceName">Username</label>
							<input name="practiceName"
                               id="practiceName"
                               type="text"
                               placeholder="Please Enter Practice Name...">
						</div>
						<div class="field">
							<label for="geolocation">Address</label>
							<input name="geolocation"
                               id="geolocation"
                               type="text"
                               placeholder="Please Enter Longitude - Latitude or Address">
                        </div>
                        
						<div class="field">
							<label for="practice_speciality">Specialty</label>
							<input name="practice_speciality"
                            id="practice_speciality"
                            type="text"
                            placeholder="Please Enter Practice Speciality">
                        </div>
                        
						<div class="field">
							<label for="practice_services">Services</label>
							<input name="practice_services"
                            id="practice_services"
                            type="text"
                            placeholder="Please Enter Practice Services">
						</div>
                        
						<div class="field">
							<label for="office_hours">Office Hours</label>
							<input nname="office_hours"
                            id="office_hours"
                            type="text"
                            placeholder="Please Enter Office Hours eg, 09H00-13h00">
						</div>
						<ul class="actions">
							<li><input value="Continue" class="button alt" type="submit"></li>
						</ul>
					</form>

						</div>
						<footer>
                            <p>Or</p>
							<a href="<?php echo $_ROOT_.'?currView=signin';?>" class="button alt">Sign In</a>
						</footer>
					</article>
				</div>
            </section>