<?php 
session_start();
$_ROOT_ = 'http://localhost:8888/Kasicare_/public/';
class Model
{
    public $string;
    public $navlinks;
    public $currentView;

    public function __construct(){
        $this->string = '<h1 style="color:red;margin:2em auto;">|</h1>';
        $this->navlinks = array(
            "home" => array(
                "Home" => "home",
            ),
            "notifications" => array(
                "Notifications" => "notifications",
            ),
            "dashboard" => array(
                "Dashboard" => "dashboard",
            ),
            "profile" => array(
                "Profile" => "profile",
            ),
            "statistics" => array(
                "Statistics" => "stats_",
            ),
            "survey_tool" => array(
                "Survey Tool" => "survey_tool",
            )
        );
        $this->Containers = ['banner', 'one', 'footer'];
        $this->currentView = "src/views/home.php";
    }
}

class View
{
    private $model;
    private $controller;

    public function __construct($controller,$model) {
        $this->controller = $controller;
        $this->model = $model;
    }

    public function home() {
        $this->model->currentView = "src/views/signin.php";
        return $this->model->currentView;
        //return '<p>' . $this->model->string . '<a href="index.php?action=clicked">Test</a></p>';
    }

    public function navlinks() {
        foreach($this->model->navlinks as $li){
            $a .= "<li>";
            foreach ($li as $k => $url){
                $a .= "<a href='".$_ROOT_."?currView=".$url."'>".$k."</a>";
            }
            $a .= "</li>";
        }
        return $a;
    }

    //Kinda Extra Mile
    public function section($data) {
        return $data;
    }

    public function footer($data) {
        return $data;
    }
}

class Controller
{
    private $model;

    public function __construct($model){
        $this->model = $model;
    }


    public function home() {
        unset($_SESSION['cView']);
        $this->model->currentView = "src/views/home.php";
        return $this->model->currentView;
    }

    public function notifications() {
        $this->model->currentView = "src/views/notifications.php";
        return $this->model->currentView;
    }

    public function dashboard() {
        $this->model->currentView = "src/views/dashboard.php";
        return $this->model->currentView;
    }

    public function profile() {
        $_SESSION['username'] = 'User7498';
        $this->model->currentView = "src/views/profile.php";
        return $this->model->currentView;
    }

    public function settings() {
        $this->model->currentView = "src/views/settings.php";
        return $this->model->currentView;
    }

    public function stats_() {
        $this->model->currentView = "src/views/stats.php";
        return $this->model->currentView;
    }

    public function survey_tool() {
        $this->model->currentView = "src/views/survey_tool.php";
        return $this->model->currentView;
    }

    public function signin() {
        $this->model->currentView = "src/views/signin.php";
        return $this->model->currentView;
    }

    public function signup() {
        $this->model->currentView = "src/views/signup.php";
        return $this->model->currentView;
    }
}

$model = new Model();
$controller = new Controller($model);
$view = new View($controller, $model);

if (isset($_GET['currView']) && !empty($_GET['currView'])) {
    $_SESSION['cView'] = $controller->{$_GET['currView']}();
    header('Location: '.$_ROOT_);
}