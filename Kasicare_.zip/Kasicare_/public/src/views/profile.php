<section id="banner" class="bg-img" data-bg="banner.jpg">
				<div class="inner">
					<header>
						<h2 class="welcome"><?php echo $_SESSION['username'];?><image src="../resources/images/profile.png" class="avatar image right"/></h2>
					</header>
					
						<footer>
							<a href="<?php echo $_ROOT_;?>?currView=dashboard" class="button special">Dashboard</a>
							<a href="<?php echo $_ROOT_;?>?currView=notifications" class="button special">Notifications</a>
							<a href="<?php echo $_ROOT_;?>?currView=settings" class="button special">Settings</a>
						</footer>
				</div>
				<a href="#one" class="more">Next Section</a>
			</section>

		<!-- One -->
			<section id="one" class="wrapper post bg-img" data-bg="banner2.jpg">
				<div class="inner">
					<article class="box">
						<header>
							<h2>Practice Name</h2>
							<p>Short Description If Any...</p>
						</header>
						<div class="content half left">
							<p>Availaility : Available</p>
                        </div>
                        
						<div class="content half right">
							<p>Rating: 3.8/5</p>
							<p>Mon - Fri: 08H00 - 16H00</p>
                        </div>
                        
						<footer>
							<a href="<?php echo $_ROOT_;?>?currView=settings" class="button alt">Settings</a>
						</footer>
					</article>
				</div>
				<a href="#two" class="more">Next Section</a>
            </section>
		<!-- Two -->
        <section id="two" class="wrapper post bg-img" data-bg="banner3.jpg">
				<div class="inner">
					<article class="box">
						
						<div class="content">
							<image class="full" src="../resources/images/map.png">
                        </div>
                        
						
					</article>
				</div>
            </section>