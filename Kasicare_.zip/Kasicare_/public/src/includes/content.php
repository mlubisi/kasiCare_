<?php 

include $_SESSION['cView'];