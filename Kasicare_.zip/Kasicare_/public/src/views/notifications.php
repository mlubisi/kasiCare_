
<section id="banner" class="bg-img" data-bg="banner.jpg">
				<div class="inner">
					<header>
						<h2 class="welcome">Notifications(0)</h2>
					</header>
					
						<footer>
							<a href="<?php echo $_ROOT_;?>?currView=profile" class="button special">Profile</a>
						</footer>
				</div>
			</section>
