
<section id="banner" class="bg-img" data-bg="banner.jpg">
				<div class="inner">
					<header>
						<h2 class="welcome">acquire access to better health <br>care</h2>
					</header>
					
						<footer>
							<a href="<?php echo $_ROOT_;?>?currView=signin" class="button special">Get Started</a>
						</footer>
				</div>
				<a href="#one" class="more">Next Section</a>
			</section>

		<!-- One -->
			<section id="one" class="wrapper post bg-img" data-bg="banner2.jpg">
				<div class="inner">
					<article class="box">
						<header>
							<h2>Summery</h2>
							<p>A WeThinkCode SocialTech Project</p>
						</header>
						<div class="content">
						<image src="../resources/images/find-med.png" class="image right"/>
							<p>KasiCare is a mobile/webapp that is meant to help township residents acquire access to better health care with the least amount of effort on their part be it financial or resource oriented.</p>
						</div>
						<footer>
							<a href="#0" class="button alt">Read More</a>
						</footer>
					</article>
				</div>
				<a href="#footer" class="more">Next Section</a>
            </section>
            

			<footer id="footer" class="wrapper post bg-img" data-bg="banner3.jpg">
				<div class="inner">

					<h2>Talk To Us</h2>

					<form action="#" method="post">

						<div class="field half first">
							<label for="name">Name</label>
							<input name="name" id="name" type="text" placeholder="Name">
						</div>
						<div class="field half">
							<label for="email">Email</label>
							<input name="email" id="email" type="email" placeholder="Email">
						</div>
						<div class="field">
							<label for="message">Message</label>
							<textarea name="message" id="message" rows="6" placeholder="Message"></textarea>
						</div>
						<ul class="actions">
							<li><input value="Send Message" class="button alt" type="submit"></li>
						</ul>
					</form>

					<ul class="icons">
						<li><a href="#" class="icon kasicare"><span class="label">KasiCare</span></a></li>
						<li><a href="#" class="icon wtc_"><span class="label">WeThinkCode</span></a></li>
					</ul>

					<div class="copyright">
						&copy; All Rights Reseverd KasiCare 2018.
					</div>

				</div>
			</footer>