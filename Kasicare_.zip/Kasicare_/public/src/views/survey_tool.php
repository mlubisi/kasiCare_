<section id="banner" class="bg-img" data-bg="banner3.jpg">
				<div class="inner">
					<header>
						<h2 class="welcome">Dev In Progress...<image src="../resources/images/find-med.png" class="avatar image right"/></h2>
					</header>
					
						<footer>
							<a href="<?php echo $_ROOT_;?>?currView=profile" class="button special">Ok</a>
						</footer>
				</div>
			</section>
