<?php include_once ('core.php'); ?>
<!DOCTYPE html>
<html>
	<head>
		<link rel="icon" type="image/png" href="../resources/images/kasicare.png" />
		<title>KasiCare</title>
		<meta charset="utf-8" />
        <meta name="viewport" content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0" />
        <meta http-equiv="X-UA-Compatible" content="ie=edge" />
		<link rel="stylesheet" href="css/reset_and_common.css" />
		<link rel="stylesheet" href="css/bases.css" />
		<link rel="stylesheet" href="css/header.css" />
		<link rel="stylesheet" href="css/footer.css" />
	</head>
	<body>

		<!-- Header -->
			<header id="header">
				<div class="logo"><a href="<?php echo $_ROOT_.'?currView=home';?>" class="kasicare"></a></div>
				<a href="#menu"><span>Menu</span></a>
			</header>

        <!-- Nav -->
			<nav id="menu">
				<ul class="links">
                <?php echo $view->navlinks(); ?>
				</ul>
			</nav>