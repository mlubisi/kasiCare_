
		<!-- One -->
        <section id="one" class="wrapper post bg-img" data-bg="banner2.jpg">
				<div class="inner">
					<article class="box">
						<header>
							<h2>Log:</h2>
							<p>Short Description If Any...</p>
						</header>
						<div class="content half left">
							<p>112 : Patients</p>
                        </div>
                        
						<div class="content half right">
							<p>231 : Appointment(s)</p>
                        </div>
                        
						<div class="content half left">
							<p>232 : Email(s)</p>
                        </div>
                        
						<div class="content half right">
							<p>0 : Notification(s)</p>
                        </div>
                        
						<div class="content half right">
							<p>42 : Appointment(s)</p>
                        </div>
                        

						<footer>
							<a href="<?php echo $_ROOT_;?>?currView=profile" class="button alt">Profile</a>
						</footer>
					</article>
				</div>
            </section>